/**
 * @flow
 * @relayHash 91a2d56e033743138012e0bb1400b3b1
 */

/* eslint-disable */

'use strict';

/*::
import type {ConcreteBatch} from 'relay-runtime';
export type CreateUserMutationVariables = {|
  createUserInput: {
    username: string;
    password: string;
    fullname: string;
    clientMutationId?: ?string;
  };
  loginUserInput: {
    username: string;
    password: string;
    clientMutationId?: ?string;
  };
|};

export type CreateUserMutationResponse = {|
  +createUser: ?{|
    +message: ?string;
  |};
  +loginUser: ?{|
    +user: ?{|
      +id: string;
      +username: ?string;
      +password: ?string;
      +fullname: ?string;
    |};
  |};
|};
*/


/*
mutation CreateUserMutation(
  $createUserInput: CreateUserInput!
  $loginUserInput: LoginUserInput!
) {
  createUser(input: $createUserInput) {
    message
  }
  loginUser(input: $loginUserInput) {
    user {
      id
      username
      password
      fullname
    }
  }
}
*/

const batch /*: ConcreteBatch*/ = {
  "fragment": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "createUserInput",
        "type": "CreateUserInput!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "loginUserInput",
        "type": "LoginUserInput!",
        "defaultValue": null
      }
    ],
    "kind": "Fragment",
    "metadata": null,
    "name": "CreateUserMutation",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "input",
            "variableName": "createUserInput",
            "type": "CreateUserInput!"
          }
        ],
        "concreteType": "CreateUserPayload",
        "name": "createUser",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "message",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "input",
            "variableName": "loginUserInput",
            "type": "LoginUserInput!"
          }
        ],
        "concreteType": "LoginUserPayload",
        "name": "loginUser",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "args": null,
            "concreteType": "User",
            "name": "user",
            "plural": false,
            "selections": [
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "id",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "username",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "password",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "fullname",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "type": "Mutation"
  },
  "id": null,
  "kind": "Batch",
  "metadata": {},
  "name": "CreateUserMutation",
  "query": {
    "argumentDefinitions": [
      {
        "kind": "LocalArgument",
        "name": "createUserInput",
        "type": "CreateUserInput!",
        "defaultValue": null
      },
      {
        "kind": "LocalArgument",
        "name": "loginUserInput",
        "type": "LoginUserInput!",
        "defaultValue": null
      }
    ],
    "kind": "Root",
    "name": "CreateUserMutation",
    "operation": "mutation",
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "input",
            "variableName": "createUserInput",
            "type": "CreateUserInput!"
          }
        ],
        "concreteType": "CreateUserPayload",
        "name": "createUser",
        "plural": false,
        "selections": [
          {
            "kind": "ScalarField",
            "alias": null,
            "args": null,
            "name": "message",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "kind": "LinkedField",
        "alias": null,
        "args": [
          {
            "kind": "Variable",
            "name": "input",
            "variableName": "loginUserInput",
            "type": "LoginUserInput!"
          }
        ],
        "concreteType": "LoginUserPayload",
        "name": "loginUser",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "args": null,
            "concreteType": "User",
            "name": "user",
            "plural": false,
            "selections": [
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "id",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "username",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "password",
                "storageKey": null
              },
              {
                "kind": "ScalarField",
                "alias": null,
                "args": null,
                "name": "fullname",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ]
  },
  "text": "mutation CreateUserMutation(\n  $createUserInput: CreateUserInput!\n  $loginUserInput: LoginUserInput!\n) {\n  createUser(input: $createUserInput) {\n    message\n  }\n  loginUser(input: $loginUserInput) {\n    user {\n      id\n      username\n      password\n      fullname\n    }\n  }\n}\n"
};

module.exports = batch;
