import React, { Component } from "react";
import ListPage from "./components/ListPage";

class App extends Component {
    render() {
        return <ListPage />;
    }
}

export default App;
